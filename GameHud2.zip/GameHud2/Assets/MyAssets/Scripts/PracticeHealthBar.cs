﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PracticeHealthBar : MonoBehaviour
{
    public Image[] healthImgs; 
    PlayerHealth playerHealth;
    int health;


    // Start is called before the first frame update
    void Start()
    {
        playerHealth = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerHealth>();
    }

    // Update is called once per frame
    void Update()
    {
        health = playerHealth.health;

        switch (health)
        {
            case 10:
                foreach (Image img in healthImgs)
                {
                    img.gameObject.SetActive(true);
                }
            break;

            case 9:
                healthImgs[0].gameObject.SetActive(true);
                healthImgs[1].gameObject.SetActive(true);
                healthImgs[2].gameObject.SetActive(true);
                healthImgs[3].gameObject.SetActive(true);
                healthImgs[4].gameObject.SetActive(true);
                healthImgs[5].gameObject.SetActive(true);
                healthImgs[6].gameObject.SetActive(true);
                healthImgs[7].gameObject.SetActive(true);
                healthImgs[8].gameObject.SetActive(true);
                healthImgs[9].gameObject.SetActive(false);
                break;

            case 8:
                healthImgs[0].gameObject.SetActive(true);
                healthImgs[1].gameObject.SetActive(true);
                healthImgs[2].gameObject.SetActive(true);
                healthImgs[3].gameObject.SetActive(true);
                healthImgs[4].gameObject.SetActive(true);
                healthImgs[5].gameObject.SetActive(true);
                healthImgs[6].gameObject.SetActive(true);
                healthImgs[7].gameObject.SetActive(true);
                healthImgs[8].gameObject.SetActive(false);
                healthImgs[9].gameObject.SetActive(false);
                break;

            case 7:
                healthImgs[0].gameObject.SetActive(true);
                healthImgs[1].gameObject.SetActive(true);
                healthImgs[2].gameObject.SetActive(true);
                healthImgs[3].gameObject.SetActive(true);
                healthImgs[4].gameObject.SetActive(true);
                healthImgs[5].gameObject.SetActive(true);
                healthImgs[6].gameObject.SetActive(true);
                healthImgs[7].gameObject.SetActive(false);
                healthImgs[8].gameObject.SetActive(false);
                healthImgs[9].gameObject.SetActive(false);
                break;

            case 6:
                healthImgs[0].gameObject.SetActive(true);
                healthImgs[1].gameObject.SetActive(true);
                healthImgs[2].gameObject.SetActive(true);
                healthImgs[3].gameObject.SetActive(true);
                healthImgs[4].gameObject.SetActive(true);
                healthImgs[5].gameObject.SetActive(true);
                healthImgs[6].gameObject.SetActive(false);
                healthImgs[7].gameObject.SetActive(false);
                healthImgs[8].gameObject.SetActive(false);
                healthImgs[9].gameObject.SetActive(false);
                break;

            case 5:
                healthImgs[0].gameObject.SetActive(true);
                healthImgs[1].gameObject.SetActive(true);
                healthImgs[2].gameObject.SetActive(true);
                healthImgs[3].gameObject.SetActive(true);
                healthImgs[4].gameObject.SetActive(true);
                healthImgs[5].gameObject.SetActive(false);
                healthImgs[6].gameObject.SetActive(false);
                healthImgs[7].gameObject.SetActive(false);
                healthImgs[8].gameObject.SetActive(false);
                healthImgs[9].gameObject.SetActive(false);
                break;

            case 4:
                healthImgs[0].gameObject.SetActive(true);
                healthImgs[1].gameObject.SetActive(true);
                healthImgs[2].gameObject.SetActive(true);
                healthImgs[3].gameObject.SetActive(true);
                healthImgs[4].gameObject.SetActive(false);
                healthImgs[5].gameObject.SetActive(false);
                healthImgs[6].gameObject.SetActive(false);
                healthImgs[7].gameObject.SetActive(false);
                healthImgs[8].gameObject.SetActive(false);
                healthImgs[9].gameObject.SetActive(false);
                break;

            case 3:
                healthImgs[0].gameObject.SetActive(true);
                healthImgs[1].gameObject.SetActive(true);
                healthImgs[2].gameObject.SetActive(true);
                healthImgs[3].gameObject.SetActive(false);
                healthImgs[4].gameObject.SetActive(false);
                healthImgs[5].gameObject.SetActive(false);
                healthImgs[6].gameObject.SetActive(false);
                healthImgs[7].gameObject.SetActive(false);
                healthImgs[8].gameObject.SetActive(false);
                healthImgs[9].gameObject.SetActive(false);
                break;

                case 2:
                healthImgs[0].gameObject.SetActive(true);
                healthImgs[1].gameObject.SetActive(true);
                healthImgs[2].gameObject.SetActive(false);
                healthImgs[3].gameObject.SetActive(false);
                healthImgs[4].gameObject.SetActive(false);
                healthImgs[5].gameObject.SetActive(false);
                healthImgs[6].gameObject.SetActive(false);
                healthImgs[7].gameObject.SetActive(false);
                healthImgs[8].gameObject.SetActive(false);
                healthImgs[9].gameObject.SetActive(false);
                break;

                case 1:
                healthImgs[0].gameObject.SetActive(true);
                healthImgs[1].gameObject.SetActive(false);
                healthImgs[2].gameObject.SetActive(false);
                healthImgs[3].gameObject.SetActive(false);
                healthImgs[4].gameObject.SetActive(false);
                healthImgs[5].gameObject.SetActive(false);
                healthImgs[6].gameObject.SetActive(false);
                healthImgs[7].gameObject.SetActive(false);
                healthImgs[8].gameObject.SetActive(false);
                healthImgs[9].gameObject.SetActive(false);
                break;

                case 0:
                healthImgs[0].gameObject.SetActive(false);
                healthImgs[1].gameObject.SetActive(false);
                healthImgs[2].gameObject.SetActive(false);
                healthImgs[3].gameObject.SetActive(false);
                healthImgs[4].gameObject.SetActive(false);
                healthImgs[5].gameObject.SetActive(false);
                healthImgs[6].gameObject.SetActive(false);
                healthImgs[7].gameObject.SetActive(false);
                healthImgs[8].gameObject.SetActive(false);
                healthImgs[9].gameObject.SetActive(false);
                Debug.Log("Player Is Dead");
                break;

               
        } 



    }
}
