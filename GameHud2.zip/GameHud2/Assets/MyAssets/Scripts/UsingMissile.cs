﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UsingMissile : MonoBehaviour
{
  public void UseMissile (int round)
    {
        MissileStorage missileCounter = GameObject.FindGameObjectWithTag("Missile").GetComponent<MissileStorage>();
        missileCounter.FireMissile(round);
    }
}
