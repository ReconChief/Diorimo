﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MissileCounter : MonoBehaviour
{
    public Image[] missileImgs;
    MissileCounter missileCounter;
    int missile;


    private void Start()
    {
        missileCounter = GameObject.FindGameObjectWithTag("Missile").GetComponent<MissileCounter>();
    }

    private void Update()
    {
        missile = missileCounter.missile;
        
        switch (missile)
        {
            case 3:
                foreach (Image img in missileImgs)
                {
                    img.gameObject.SetActive(true);
                }
                break;

            case 2:
                missileImgs[0].gameObject.SetActive(true);
                missileImgs[1].gameObject.SetActive(true);
                missileImgs[2].gameObject.SetActive(false);
                break;

            case 1:
                missileImgs[0].gameObject.SetActive(true);
                missileImgs[1].gameObject.SetActive(false);
                missileImgs[2].gameObject.SetActive(false);
                break;

            case 0:
                missileImgs[0].gameObject.SetActive(false);
                missileImgs[1].gameObject.SetActive(false);
                missileImgs[2].gameObject.SetActive(false);
                Debug.Log("Out of Missiles");
                break;
        }
    }

}
