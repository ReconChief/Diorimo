﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MissileStorage : MonoBehaviour
{
    public int missile;

    public void FireMissile(int round) 
        {
             missile -= round;
        Debug.Log("Missile " + missile.ToString());
        } 
}
